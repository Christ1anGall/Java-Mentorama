package br.com.alunos.Aula.AlunosAula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlunosAulaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlunosAulaApplication.class, args);
	}

}
